#include <stdio.h>

#define NUM 10

main()
{
  int i;
  
  for(i=0 ; i<NUM ; i++)
    printf("Hello World!\n");
}
